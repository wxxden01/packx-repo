#!/bin/bash

# 1. Chargement immédiat des variables exportées par le programme C
if [ -f /etc/profile.d/packx-var.sh ]; then
    source /etc/profile.d/packx-var.sh
fi

# 2. Installation
mv btop $PACKX_SOURCE
