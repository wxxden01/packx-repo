#!/bin/bash
set -e

PKG_NAME="${1:-btop}"
PKG_DIR="/var/lib/packx/pkgs/$PKG_NAME"

echo "Suppression de $PKG_NAME"

if [ "$EUID" -ne 0 ]; then
    echo "Ce script doit etre lance avec sudo"
    exit 1
fi

rm -f "/usr/local/bin/$PKG_NAME"
rm -rf "$PKG_DIR"

if [ -f /var/lib/packx/installed.db ]; then
    sed -i "/^$PKG_NAME|/d" /var/lib/packx/installed.db
fi

echo "Suppression terminee"
