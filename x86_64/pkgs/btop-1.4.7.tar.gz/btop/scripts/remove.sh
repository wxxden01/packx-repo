#!/bin/bash
set -e

PKG_NAME="btop"
PKG_DIR="/var/lib/packx/pkgs/$PKG_NAME"
INSTALLED_DB="/var/lib/packx/installed.db"
BUILD_DIR="/var/cache/packx/build"

echo "Désinstallation du paquet $PKG_NAME..."

# 1. Suppression du lien symbolique dans /usr/local/bin
if [ -L /usr/local/bin/btop ]; then
    echo "Suppression du lien symbolique /usr/local/bin/btop..."
    rm -f /usr/local/bin/btop
else
    echo "Le lien symbolique /usr/local/bin/btop n'existe pas, ignorance."
fi

# 2. Suppression du répertoire d'installation du paquet
if [ -d "$PKG_DIR" ]; then
    echo "Suppression du répertoire $PKG_DIR..."
    rm -rf "$PKG_DIR"
else
    echo "Le répertoire $PKG_DIR n'existe pas, ignorance."
fi

# 3. Retrait de l'entrée dans la base de données des paquets installés
if [ -f "$INSTALLED_DB" ]; then
    echo "Mise à jour de la base de données $INSTALLED_DB..."
    # Supprime toute ligne commençant par "btop|"
    sed -i "/^${PKG_NAME}|/d" "$INSTALLED_DB"
else
    echo "La base de données $INSTALLED_DB n'existe pas, ignorance."
fi

# 4. Nettoyage des éventuels restes du répertoire de build (optionnel mais recommandé)
if [ -d "$BUILD_DIR" ]; then
    echo "Nettoyage du répertoire de build $BUILD_DIR..."
    rm -rf "$BUILD_DIR"
fi

echo "Désinstallation de $PKG_NAME terminée avec succès."
