#!/bin/bash
set -e

PKG_NAME="btop"
PKG_VER="1.4.7"
HASH="sha256:5099054dd6a101bd12eb6ff3702a9a6a3f57aaa27923a0da478ae5b517faf335"
SOURCE_URL="https://github.com/aristocratos/btop/releases/download/v$PKG_VER/btop-x86_64-unknown-linux-musl.tar.gz"
GDE="/var/cache/packx"
BUILD_DIR="$GDE/build"

echo "Telechargement depuis GitHub..."
cd $GDE
wget -P $BUILD_DIR -O $PKG_NAME-src.tar.gz $SOURCE_URL 

echo "Extraction..."
mkdir $BUILD_DIR
tar -xf "$PKG_NAME-src.tar.gz" -C $BUILD_DIR/ 
echo "Compilation..."
cd $BUILD_DIR/$PKG_NAME
make -j$(nproc)

echo "Installation..."
PKG_DIR="/var/lib/packx/pkgs/$PKG_NAME"
mkdir -p $PKG_DIR
mkdir -p "$PKG_DIR/usr/bin"
cp $BUILD_DIR/btop/bin/btop $PKG_DIR/usr/bin/
chmod 755 "$PKG_DIR/usr/bin/btop"

ln -sf "$PKG_DIR/usr/bin/btop" /usr/local/bin/btop

echo "$PKG_NAME|$PKG_VER|e|E" >> /var/lib/packx/installed.db

rm -rf $BUILD_DIR *

echo "Installation terminee"
